library(shiny)

runApp("E:/aWork/Software/R/RRegman")
