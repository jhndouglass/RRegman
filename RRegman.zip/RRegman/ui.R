#setwd("~/ShinyApps/CSF_web_regman")
setwd("E:/aWork/Software/R/RRegman")
load("moddat.rdata")
site <- as.list(as.character(moddat$CATCHMENT))


shinyUI(pageWithSidebar(
  # title
  headerPanel(
    list(HTML('<img src="CSF.png"/>'), "   CSF regression model viewer"),
    windowTitle="CSF regresion models shiny app"),

  # sidebar
  sidebarPanel(
    tabsetPanel(
      tabPanel("Main",
        helpText("This is the CSF regression model viewer. It displays predictions
                 of water quality improvements from the third CSF evaluation.
                 Select graphs, tables or maps and then have a play with the options
                 in the sidebar to explore the results.
                 If you're interested you can also model diagnostics and download
                 the R model objects by choosing model, below. Sadly we can't make
                 the training or prediction data sets avialable on the web."),

        radioButtons(
          "choice",
          "Select view",
          choices = c("Graphs" , "Tables", "Maps", "Models")
        ),


        conditionalPanel(
          condition = "input.choice == 'Tables' |
          input.choice == 'Graphs'",
          selectInput(
            "site",
            "Select Target Area",
            choices = site)),

        selectInput(
          "det",
          "Select Determinand",
          choices = c("Orthophosphate", "Total Phosphorus", "Ammoniacal Nitrogen",
                      "TON", "Suspended Solids")),

        conditionalPanel(
          condition = "input.choice == 'Maps'",
          selectInput(
            "sce",
            "Select Scenario to map",
            choices = c("Baseline" = "base.out", "Current" = "curr.out",
                        "Extrapolated" = "extrap.out", "Optimised" = "optim.out",
                        "Maximum CSF" = "max.out",
                        "Maximum agricultural benefit" = "maxben.out",
                        "Headroom" = "head.out",
                        "Current reductions" = "curr.reduct",
                        "Extrapolated reductions" = "extrap.reduct",
                        "Optimised Reductions" = "optim.reduct",
                        "Maximum CSF reductions" = "max.reduct",
                        "Maximum agricultural benefit reductions" = "maxben.reduct",
                        "Headroom reductions" = "head.reduct"))),

        conditionalPanel(
          condition = "input.choice == 'Graphs'",
          checkboxInput(
            "lim",
            "Toggle Environmental Quality Standard on graph"),
          numericInput(
            "eqs",
            "Set Environmental Quality Standard value (mg/l)",
            0)),

        div(style = "margin-top: 25px; width = 50px; ", HTML('<img src="EA.png"/>')),

        div(style = "margin-top: 25px; width = 50px; ", HTML('<img src="NE.png"/>'))
          ),

    tabPanel("Scenarios",
             h5("Baseline"),
             p("This is is predicted concentration (mg/l) of a given pollutant
               as an average ", em("across"), " the target area"),

             h5("Current"),
             p("some text here"),

             h5("Extrapolated"),
             p("some text here"),

             h5("Optimised"),
             p("some text here"),

             h5("Maximum CSF"),
             p("some text here"),

             h5("Maximum Agricultural"),
             p("some text here"),

             h5("Headroom"),
             p("some text here"),

             div(style = "margin-top: 25px; width = 50px; ", HTML('<img src="EA.png"/>')),

             div(style = "margin-top: 25px; width = 50px; ", HTML('<img src="NE.png"/>'))
             )
    )),

  mainPanel(
    conditionalPanel(
      condition = "input.choice == 'Graphs'",
      textOutput("graph_title_c"),
      textOutput("graph_title_a"),
      textOutput("graph_title_b"),
      plotOutput("rect_graph"),
      downloadButton("graph_dl", "Save image")),
    conditionalPanel(
      condition = "input.choice == 'Tables'",
      textOutput("tab_title1c"),
      textOutput("tab_title1a"),
      textOutput("tab_title1b"),
      tableOutput("tab_dat1"),
      textOutput("tab_title2c"),
      textOutput("tab_title2a"),
      textOutput("tab_title2b"),
      tableOutput("tab_dat2"),
      downloadButton("tab_dl", "Download all TA predictions for detminand"),
      downloadButton("datbook_dl", "Download description of columns")),
    conditionalPanel(
      condition = "input.choice == 'Maps'",
      textOutput("map_title_c"),
      textOutput("map_title_a"),
      textOutput("map_title_b"),
      plotOutput("map"),
      downloadButton("map_dl", "Save map")),
    conditionalPanel(
      condition = "input.choice == 'Models'",
      textOutput("mod_title"),
      plotOutput("mod_diag"),
      verbatimTextOutput("mod_summ"),
      downloadButton("mod_dl", "Download R model object"))
  )
)
)
